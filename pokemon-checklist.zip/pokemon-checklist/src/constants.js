export const MASTER_COUNTS = {
    JourneyTogether: 190,
    TemporalForces: 218,
    ObsidianFlames: 230,
    PrismaticEvolutions: 180,
  };
  
  export const BASE_COUNTS = {
    JourneyTogether: 159,
    TemporalForces: 162,
    ObsidianFlames: 197,
    PrismaticEvolutions: 131,
  };
  
  export const SET_CODES = {
    JourneyTogether: 'sv9',
    TemporalForces: 'sv5',
    ObsidianFlames: 'sv3',
    PrismaticEvolutions: 'sv8pt5'
  };  